﻿#include "PhanSo.h"


int PhanSo::UCLN(int a, int b)
{
	int c;
	while ((c = (a%b)) != 0)
	{
		a = b;
		b = c;
	}
	return b;
}
void PhanSo::RutGon(PhanSo &a)
{
	int temp = UCLN(a.TS, a.MS);
	a.TS = a.TS / temp;
	a.MS = a.MS / temp;
}



bool PhanSo ::operator>(PhanSo a)
{
	int uc = UCLN(this->MS, a.MS);
	if (this->TS*uc > a.TS*uc)
		return true;
	else return false;
}
bool PhanSo ::operator<(PhanSo a)
{
	int uc = UCLN(this->MS, a.MS);
	if (this->TS*uc < a.TS*uc)
		return true;
	else return false;
}
//--Nhập Xuất --//
istream& operator>>(istream &input, PhanSo &a)
{
	cout << "\nNhap Vao Tu So: ";
	input >> a.TS;
	do{
		cout << "Nhap Vao Mau So: ";
		input >> a.MS;
		if (a.MS == 0)cout << "Nhap MS !=0\n ";
	} while (a.MS == 0);
	return input;
}
ostream& operator<<(ostream &output, PhanSo b)
{
	if (b.TS == b.MS)b.TS = b.MS = 1;
	if (b.MS == 1)
	{
		cout << b.TS;
		return output;
	}
	cout << b.TS << "/" << b.MS;
	return output;
}
PhanSo::PhanSo(int TuSo, int MauSo)
{
	this->TS = TuSo; this->MS = MauSo;
}
PhanSo::PhanSo()
{
	this->TS = 0; this->MS = 1;
}
PhanSo::~PhanSo()
{
}