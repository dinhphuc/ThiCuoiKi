#include "PhanSo.h"

void main()
{
	PhanSo A(3, 2),B(3,2);
	if (A < B)cout << "Dung";
	else cout << "Sai";
	cout << endl;
	system("pause");
}